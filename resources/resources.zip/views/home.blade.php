@extends('layouts.app')

@section('content')
<div class="container">
    <h2 id="title" align="center" class="blanco-fuente main-titulo">Administracion de Inglés</h2>
    <center>
      <img style="margin-top:5%;" src="{{ URL::asset('imgs/main.gif')}}" width="400px">
    </center>
    <h2 id="title" align="center" class="blanco-fuente main-titulo">ITCV</h2>

</div>
@endsection
